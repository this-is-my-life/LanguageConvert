nw.Window.open('index.html', {}, function(win) {});
